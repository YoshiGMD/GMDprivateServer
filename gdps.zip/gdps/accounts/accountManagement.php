<?php
header("Location: ../dashboard");
?>